#pragma once

#include <cinder/cinder.h>
#include <cinder/app/AppBasic.h>

#include <memory>

class PlaygroundApp : public ci::app::AppBasic {
  struct Data;
  std::unique_ptr<Data> d;

public:
  PlaygroundApp();
  ~PlaygroundApp();

  void draw() final;
  void update() final;
};
