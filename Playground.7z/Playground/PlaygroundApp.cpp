#include "PlaygroundApp.h"

#include <cinder/gl/gl.h>

using namespace ci;
using namespace ci::app;

using namespace std;

struct PlaygroundApp::Data {};

PlaygroundApp::PlaygroundApp() : d(make_unique<Data>()) {}

PlaygroundApp::~PlaygroundApp() {}

void PlaygroundApp::update() {}

void PlaygroundApp::draw() {}

CINDER_APP_BASIC(PlaygroundApp, RendererGl)
